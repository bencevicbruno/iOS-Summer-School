import UIKit

//let name = "Bruno" // subscripting
//
//let letter = name[name.index(name.startIndex, offsetBy: 3)]

//extension String {
//    subscript(i: Int) -> String {
//        return String(self[index(startIndex, offsetBy: i)])
//    }
//
//    func deletePrefix(_ prefix: String) -> String {
//        guard self.hasPrefix(prefix) else { return self }
//        return String(self.dropFirst(prefix.count))
//    }
//
//    func deleteSuffix(_ suffix: String) -> String {
//        guard self.hasSuffix(suffix) else { return self }
//        return String(self.dropLast(suffix.count))
//    }
//
//    func containsAny(of array: [String]) -> Bool {
//        for item in array {
//            if self.contains(item) {
//                return true
//            }
//        }
//
//        return false
//    }
//}
//
//name.contains(["haha", "hihi", "hohi"])
//
//langs = ["yes", "python", "ruby"]
//langs.contains(where: name.contains)

//let myString = "This is a test string!"
//
//let attributes: [NSAttributedString.Key: Any] = [
//    .foregroundColor: UIColor.white,
//    .backgroundColor: UIColor.red,
//    .font: UIFont.boldSystemFont(ofSize: 36)
//]
//
//let attributedString = NSAttributedString(string: myString, attributes: attributes)
//print(attributedString)
//
//let mutableAttribString = NSMutableAttributedString(string: myString)
//mutableAttribString.addAttribute(.font, value: UIFont.systemFont(ofSize: 8), range: NSRange(location: 0, length: 4))
//mutableAttribString.addAttribute(.font, value: UIFont.systemFont(ofSize: 16), range: NSRange(location: 5, length: 2))
//mutableAttribString.addAttribute(.font, value: UIFont.systemFont(ofSize: 24), range: NSRange(location: 13, length: 2))
//mutableAttribString.addAttribute(.font, value: UIFont.systemFont(ofSize: 36), range: NSRange(location: 8, length: 4))
//

// challenge:

extension String {
    func withPrefix(_ prefix: String) -> String {
        if self.hasPrefix(prefix) { return self }
        return prefix + self
    }
    
    func isNumeric() -> Bool {
        return (0..<10).map {String($0)}.contains(where: self.contains)
    }
    
    var lines: [String] {
        get {
            return self.split(separator: Character("\n")).map {String($0)}
        }
    }
}

print("Heyyo".withPrefix("Heyyo"))
print("abc3".isNumeric())
print("hello\nmy\nboy".lines)
